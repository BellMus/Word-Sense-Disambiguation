from nltk import word_tokenize
from math import log
import sys
from nltk.corpus import stopwords
import string
import os

# Implementation of Naive Bayes classifier model for Word Sense disambiguation
# implements a Bag of Words based word frequency profile model, for the distinct classes
# Implements a


# Feature processing

# REPORT
# Both the test instances are being classified correctly, giving an accuracy of 100%


model = {}
vocab_size = 0
punctuations = list(string.punctuation)
stop_words = stopwords.words("english")


# function that tokenizes and also performs other preprocessing
# like removing punctuations and stop words
def tokenize(text):
    tokens = word_tokenize(text)
    return [token for token in tokens if token not in punctuations and token not in stop_words]


# build word frequency model from the corpus data
def build_model_from_data(training_dir):

    dirs = os.listdir(training_dir)
    for class_dir_name in dirs:
        for f in os.listdir(os.path.join(training_dir, class_dir_name)):
            document = os.path.join(training_dir, class_dir_name, f)
            with open(document, 'r') as file:
                tokens = tokenize(file.read().lower())
                for token in tokens:
                    model[class_dir_name]["word_frequency"][token] =  model.setdefault(class_dir_name,{}) \
                                                             .setdefault("word_frequency", {}) \
                                                             .setdefault(token, 0) + 1

                    model[class_dir_name]["total_word_count"] = model.setdefault(class_dir_name,{}) \
                                                             .setdefault("total_word_count", 0) + 1
        pass
    pass


# get class conditional log probability for the word and the class, with laplace smoothing
def get_class_conditional_log_prob(word, c):
    return log((model[c]["word_frequency"].get(word,0) + 0.4) / (model[c]["total_word_count"] + 0.4*vocab_size))



# get term frequency for the word and the class, with laplace smoothing
def get_word_freq(word, c):
    return (model[c]["word_frequency"].get(word,0) + 0.4) / (model[c]["total_word_count"] + 0.4*vocab_size)


def build_test_dataset(test_dir):
    test_data = []
    dirs = os.listdir(test_dir)
    for class_dir_name in dirs:
        for f in os.listdir(os.path.join(test_dir, class_dir_name)):
            document = os.path.join(test_dir, class_dir_name, f)
            with open(document, 'r') as file:
                tokens = tokenize(file.read().lower())
                test_data.append((f, tokens, class_dir_name))
    return test_data

# read test cases from the test dir and make predictions using the classifier model
def predict(test_data):
    for (id, tokens, true_class) in test_data:
            max_prob = -sys.maxsize
            max_likely_class = None
            word_freq = {}

            # compute class conditional probabilities for all possible classes
            # and assign the test instance to the most likely class

            for model_class in model.keys():
                prob = 0
                for token in tokens:
                    if token in train_tokens:
                        cond_prob = get_class_conditional_log_prob(token,model_class)
                        word_freq[token][model_class] = word_freq.setdefault(token,{}).setdefault(model_class,get_class_conditional_log_prob(token, model_class))
                        prob += cond_prob

                if prob > max_prob:
                    max_prob = prob
                    max_likely_class = model_class

            # print("word frequencies are ")
            # print('\n'.join(map(str, sorted(word_freq.items(), key=lambda x: x[1]["sense_1"] - x[1]["sense_2"], reverse=True))))
            print("Prediction for: ", id, ", Actual class:", true_class, ", Predicted Class:", max_likely_class)

    pass


# this is the main program
# read the corpus data and build the model
build_model_from_data("train")

# build the vocabulory and the list of all tokens, across both train and test corpus
# train_tokens contains the tokens found in training documents across all classes
train_tokens = set()
for c in model.keys():
    vocab_size += len(model[c]["word_frequency"].keys())
    train_tokens = train_tokens.union(model[c]["word_frequency"].keys())

# make predictions on the test documents
test_data = build_test_dataset("test")
predict(test_data )


# build feature vectors
# test_tokens = set()
# for (id, tokens, true_class) in test_data:
#     test_tokens = test_tokens.union(tokens)
# all_tokens = set.union(train_tokens, test_tokens)
#
# # converting back to list to preserve the order
# all_tokens = list(all_tokens)
#
# for model_class in model.keys():
#     print(' '.join([str(round(get_class_conditional_log_prob(token, model_class), 3)) for token in all_tokens]) + ' ' + model_class)
#
# pass

#create word dictionary
