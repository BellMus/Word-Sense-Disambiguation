import wikipedia
from urllib import request
from bs4 import BeautifulSoup
import os


def scrape_web_data():
    corpus = {
        'sense_1': {"wiki_page_ids": [262642]},
        'sense_2': {"wiki_page_ids": [14755931, 3452243]}
    }

    test_corpus = {
        'sense_2': {
            "urls": ["http://www.cornellcollege.edu/academic-affairs/chair-handbook/role-of-department-chairs.shtml"]},
        'sense_1': {"urls": ["http://www.valuecityfurniture.com/search/v/living-room/seating/chairs-chaises"]}
    }

    for c in corpus:
        for pageid in corpus[c]["wiki_page_ids"]:
            page = wikipedia.page(pageid=pageid)

            file_name = os.path.join("train", c, page.pageid)
            if not os.path.exists(os.path.dirname(file_name)):
                os.makedirs(os.path.dirname(file_name))

            with open(file_name, "w") as text_file:
                text_file.write(page.content)

    for c in test_corpus.keys():
        for url in test_corpus[c]["urls"]:
        # html = request.urlopen(url).read()

            with request.urlopen(url) as response:

                # read data from the webpages for the test instances and cleanup using BeautifulSoup
                html = BeautifulSoup(response.read())
                for script in html(["script", "style"]):
                    script.extract()
                text = html.get_text()

                fileid = url.split("/")[-1]
                file_name = os.path.join("test", c, fileid)
                if not os.path.exists(os.path.dirname(file_name)):
                    os.makedirs(os.path.dirname(file_name))

                with open(file_name, "w") as text_file:
                    text_file.write(text)


scrape_web_data()